from fastapi import FastAPI, Body
from pydantic import BaseModel
from typing import Optional
import numpy as np
import joblib
import datetime
import ollama
from transformers import pipeline

app = FastAPI()


# Load your trained modelss
rf_model = joblib.load(r"chatbackend/random_forest_model.pkl")
text_model = pipeline("text-classification", model=r"stress_detector_gpt_model")

class ChatInput(BaseModel):
    message: str

def check_stress_from_text(text: str):
    result = text_model(text)
    stress_label = result[0]['label']
    return True if stress_label == 'LABEL_1' else False

def check_stress_from_smartwatch():
    accX, accY, accZ = 0.02, 0.05, 0.01
    BVP, EDA, Temp = 0.35, 0.8, 36.7
    features = np.array([[accX, accY, accZ, BVP, EDA, Temp]])
    stress_prediction = rf_model.predict(features)
    return bool(stress_prediction[0])

def generate_response(message: str, is_stressed: bool):
    context = "The user seems stressed. Respond with empathy and suggest relaxing activities or supportive words." if is_stressed else "Respond naturally to the following message."
    try:
        ollama_response = ollama.chat(model='llama3.2', messages=[
            {'role': 'system', 'content': context},
            {'role': 'user', 'content': message}
        ])
        return ollama_response['message']['content']
    except Exception as e:
        return f"Error: {e}"

@app.post("/chat")
async def chat(input_data: ChatInput = Body(...)):
    text_stress = check_stress_from_text(input_data.message)
    smartwatch_stress = check_stress_from_smartwatch()
    is_stressed = text_stress or smartwatch_stress
    response_text = generate_response(input_data.message, is_stressed)
    return {
        "timestamp": datetime.datetime.now().isoformat(),
        "response": response_text,
        "stress_detected_text": text_stress,
        "stress_detected_smartwatch": smartwatch_stress,
        "overall_stress_detected": is_stressed
    }