// src/App.jsx
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/common/Header/Header';
import Footer from './components/common/Footer/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Dashboard from './pages/Dashboard';
import ChatWithTink from './components/ChatWithTink/ChatWithTink.jsx';
import LoginForm from './components/auth/LoginForm';
import UserProfile from './components/profile/UserProfile/UserProfile.jsx';
import SignUpForm from './components/auth/SignUpForm.jsx';
import ForgotPassword from './components/auth/ForgotPassword.jsx';
import Community from './pages/Community.jsx';

import { Analytics } from "@vercel/analytics/react"
function App() {
  const location = useLocation();

  return (
    <div className="App">
      <Header />
      <Analytics />
   
      {/* Only render Home and ChatWithTink if not on the /profile route */}
      {location.pathname !== '/profile' 
      && location.pathname !== '/dashboard' 
      && location.pathname !== '/login' 
      && location.pathname !== '/register'
      && location.pathname !== '/forgot-password'
      && location.pathname !== '/community'
      && location.pathname !== '/chat'
      && (
        <>
          <Home />
    
          <ChatWithTink />
         
        </>
      )}

      <Routes  futureFlags={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/profile" element={<UserProfile />} />
        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/register" element={<SignUpForm />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/community" element={<Community />} />
      </Routes>

      <Footer />
    </div>
  );
}

function AppWrapper() {
  return (
    <Router>
      <App />
    </Router>
  );
}

export default AppWrapper;