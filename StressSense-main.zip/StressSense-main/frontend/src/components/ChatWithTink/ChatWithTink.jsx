import { useState, useEffect } from 'react';
import Fuse from 'fuse.js';
const predefinedResponses = {
  // General Greetings
  hello: "Hi there! How can I assist you today?",
  hi: "Hello! What can I do for you?",
  hey: "Hey! How's it going?",
  greetings: "Greetings! How may I help?",
  goodMorning: "Good morning! Hope you have a great start to your day.",
  goodAfternoon: "Good afternoon! What can I assist you with?",
  goodEvening: "Good evening! How's your day been so far?",
  howdy: "Howdy! What’s on your mind?",

  // Stress and Anxiety
  stress: "Stress is tough. Deep breathing or short breaks might help.",
  anxiety: "Anxiety can be challenging. Grounding exercises might work for you.",
  overwhelmed: "Feeling overwhelmed? Prioritize tasks and take it one step at a time.",
  panic: "Try to pause and focus on your breathing during panic moments.",
  pressure: "Pressure can be eased by setting realistic goals and taking breaks.",
  burnout: "Burnout is a signal to rest. Please don’t hesitate to take a break.",
  worry: "Worry less by focusing on what’s within your control.",
  nervousness: "Try calming techniques like counting breaths when nervous.",
  fear: "Facing fears can be tough; talking to someone may help.",

  // Relaxation Techniques
  relax: "Take a moment to pause and unwind. You deserve it.",
  relaxation: "Relaxation is key! Try music, meditation, or reading.",
  calmDown: "Take slow, deep breaths to calm your mind.",
  unwind: "Unwinding after a busy day is essential for mental health.",
  deStress: "De-stress with a short walk or a cup of tea.",
  breathingExercises: "Breathing exercises can quickly help reduce tension.",
  meditation: "Meditation is a great way to center yourself.",
  mindfulness: "Mindfulness can help you feel more grounded and present.",

  // Sleep and Rest
  sleep: "A good sleep routine can work wonders for your mental and physical health.",
  insomnia: "If you're struggling with insomnia, try a calming bedtime routine.",
  tiredness: "Feeling tired? A power nap might recharge you.",
  fatigue: "Fatigue can signal the need for better rest or nutrition.",
  rest: "Rest is important. Don’t forget to take breaks.",
  nap: "Even a 20-minute nap can boost energy and focus.",

  // Physical Activity and Exercise
  exercise: "Exercise can improve both your body and mind.",
  workout: "Workouts can be as simple as stretching or walking.",
  physicalActivity: "Staying active helps maintain mental balance.",
  yoga: "Yoga can improve flexibility and reduce stress.",
  walking: "A short walk can boost your mood instantly.",
  running: "Running can help clear your mind and energize you.",
  fitness: "Fitness is a journey. Start with small, achievable goals.",

  // Emotional Support and Coping Strategies
  help: "I'm here to help! Let me know what you need.",
  support: "You’re not alone. Reach out to friends or professionals.",
  coping: "Coping strategies like journaling or talking help manage emotions.",
  feelings: "It's okay to feel. Expressing them is healthy.",
  emotions: "Acknowledging your emotions is the first step to understanding them.",
  talkToSomeone: "Sharing your thoughts with someone can lighten your load.",
  reachOut: "Reaching out for support is a sign of strength.",

  // Motivation and Encouragement
  motivation: "You’ve got this! Keep pushing forward.",
  keepGoing: "Stay persistent, and you'll achieve your goals.",
  encouragement: "You're doing great! Stay the course.",
  stayPositive: "A positive mindset can make all the difference.",
  youCanDoIt: "Believe in yourself. You can do it!",

  // Mental Health Resources
  resources: "Check out articles or guides tailored to mental wellness.",
  articles: "Reading articles can provide insights and techniques.",
  tips: "Practical tips can make a big difference in your daily routine.",
  guides: "Guides offer structured approaches to managing mental health.",
  books: "Books on mindfulness or self-care might inspire you.",

  // Common Questions About Mental Health
  whatIsStress: "Stress is a natural response to challenges. Let me provide some resources.",
  whatIsAnxiety: "Anxiety is a feeling of worry or fear. Here are ways to manage it.",
  howToRelax: "Relaxation techniques like breathing exercises or meditation can help.",
  howToCopeWithStress: "Coping with stress involves self-care and seeking support.",
  benefitsOfExercise: "Exercise boosts mood, energy, and overall health.",

  // Self-Care Practices
  selfCare: "Self-care involves taking time to recharge and prioritize your needs.",
  selfLove: "Self-love is about accepting yourself as you are.",
  gratitude: "Gratitude practices can shift your focus to positive aspects of life.",
  journaling: "Journaling helps clarify thoughts and emotions.",
  beingPresent: "Being present allows you to fully experience life's moments.",
  focusOnTheMoment: "Focusing on the moment can reduce stress and improve clarity.",

  // Feedback and Improvement
  feedback: "Your feedback is invaluable. How can I improve?",
  suggestions: "I’m open to suggestions! Feel free to share your ideas.",
  improvements: "Let me know where I can make things better.",

  // Farewells
  goodbye: "Goodbye! Take care.",
  seeYouLater: "See you later! Have a wonderful day.",
  takeCare: "Take care of yourself!",
  haveANiceDay: "Have a nice day! See you soon.",

  // Additional Keywords for Specific Topics
  workLifeBalance: "Balancing work and life is vital for well-being.",
  productivity: "Productivity improves when you plan and focus.",
  timeManagement: "Time management is key to handling responsibilities efficiently.",
  focus: "Focusing on one task at a time can boost efficiency.",
  friends: "Spending time with friends enriches your life.",
  family: "Family support provides strength and comfort.",
  relationships: "Healthy relationships nurture growth and happiness.",
  community: "A strong community can be a source of support.",
  personalDevelopment: "Personal development is about learning and growing continuously.",
  growthMindset: "A growth mindset helps you turn challenges into opportunities.",
  learning: "Lifelong learning keeps your mind sharp and open.",
  
  // Default Response
  default: "I'm not sure how to help with that. Can you please elaborate?"
};


const ChatWithTink = () => {
  const [isOpen, setIsOpen] = useState(false); // State to manage chat window visibility
  const [messages, setMessages] = useState([]); // State to manage chat messages
  const [input, setInput] = useState(''); // State to manage user input

  useEffect(() => {
    if (isOpen) {
      setMessages((prev) => [...prev, { text: "Welcome! How can I assist you today?", sender: 'bot' }]);
    }
  }, [isOpen]);

  // Fuse.js options for fuzzy search
  const predefinedKeywords = Object.keys(predefinedResponses).map((key) => ({
    keyword: key,
    response: predefinedResponses[key],
  }));
  
  const fuse = new Fuse(predefinedKeywords, {
    keys: ['keyword'],
    includeScore: true,
  });

  const handleSend = () => {
    if (input.trim() === '') return; // Prevent empty messages
  
    // Add user message to chat
    setMessages((prev) => [...prev, { text: input, sender: 'user' }]);
  
    // Determine bot response based on user input
    const result = fuse.search(input.toLowerCase());
  
    // Check if there's a match
    if (result.length > 0 && result[0].score < 0.5) {
      const botResponse = result[0].item.response;
      // Add bot response to chat
      setMessages((prev) => [...prev, { text: botResponse, sender: 'bot' }]);
    } else {
      setMessages((prev) => [...prev, { text: predefinedResponses.default, sender: 'bot' }]);
    }
  
    // Clear input
    setInput('');
  };

  return (
    <div className="relative">
      {/* Chatbot Icon */}
      <div 
        onClick={() => setIsOpen(!isOpen)} 
        className="fixed bottom-5 right-5 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center cursor-pointer shadow-lg transition-transform duration-300 hover:scale-105"
      >
        <span className="text-white text-lg">💬</span> {/* Chat icon */}
      </div>

      {/* Chatbot Window */}
      {isOpen && (
        <div className="fixed bottom-20 right-10 w-80 bg-white rounded-lg shadow-lg z-50">
          <div className="p-4 border-b">
            <h2 className="text-lg font-bold">Chatbot</h2>
            <div className="h-64 overflow-y-auto p-4">
              {messages.map((msg, index) => (
                <div key={index} className={`mb-2 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
                  <span className={`inline-block px-3 py-2 rounded-lg ${msg.sender === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-black'}`}>
                    {msg.text}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="p-4 flex items-center">
            <input
              type="text"
              className="flex-grow border rounded-lg p-2"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type your message..."
            />
            <button
              className="ml-2 w-10 h-10 bg-blue-500 text-white rounded-lg flex items-center justify-center"
              onClick={handleSend}
            >
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatWithTink;