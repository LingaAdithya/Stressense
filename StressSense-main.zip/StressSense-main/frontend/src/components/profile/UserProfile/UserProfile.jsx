import { useState } from 'react';
import { 
  Camera, 
  Mail, 
  MapPin, 
  Calendar, 
  Edit2, 
  X, 
  Check, 
  Heart,
  Activity,
  Clock,
  Award,
  Bell,
  User,
  Lock,
  Smartphone,
  Moon,
  Globe,
  Download,
  Shield,
  Info,
  ChevronRight
} from 'lucide-react';

const UserProfile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [userData, setUserData] = useState({
    name: 'Mohammed Aashik F',
    stressLevel: 'Moderate',
    location: 'Chennai, India',
    email: 'mohammedaashik.f2022@vitstudent.ac.in',
    joined: 'January 2022',
    bio: 'Working on maintaining work-life balance and practicing mindfulness daily. Enjoying meditation and yoga sessions.',
    avatar: '/api/placeholder/400/400',
    streakDays: 15,
    meditationMinutes: 450,
    weeklyGoal: '3 sessions',
    preferredActivities: ['Meditation', 'Deep Breathing', 'Nature Walks']
  });

  const [editData, setEditData] = useState(userData);

  // Settings state
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [moodReminders, setMoodReminders] = useState(true);
  const [dataSharing, setDataSharing] = useState(false);
  const [profileImage, setProfileImage] = useState('/api/placeholder/100/100');

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setEditData(userData);
    setIsEditing(false);
  };

  const handleSave = () => {
    setUserData(editData);
    setIsEditing(false);
    setShowNotification(true);
    setTimeout(() => setShowNotification(false), 3000);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleImageUpload = () => {
    // In a real app, you'd handle the file upload here
    setProfileImage('/api/placeholder/100/100');
  };

  return (
    <div className="min-h-screen bg-blue-50 p-4 md:p-8">
      {showNotification && (
        <div className="fixed top-4 right-4 bg-green-100 text-green-800 px-6 py-3 rounded-lg flex items-center space-x-2 shadow-lg animate-fade-in">
          <Check className="w-5 h-5" />
          <span>Profile updated successfully!</span>
        </div>
      )}

      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md">
        <div className="relative pb-24 md:pb-32 bg-gradient-to-r from-blue-400 to-purple-400 rounded-t-lg">
          <div className="absolute -bottom-16 left-4 md:left-8">
            <div className="relative">
              <img
                src="/src/assets/image.png"
                alt="Profil"
                className="w-32 h-32 rounded-full border-4 border-white shadow-lg"
              />
              {!isEditing && (
                <button className="absolute bottom-0 right-0 p-2 bg-white rounded-full shadow-md hover:bg-gray-50 transition-colors">
                  <Camera className="w-5 h-5 text-gray-600" />
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="pt-20 p-6">
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                {isEditing ? (
                  <input
                    name="name"
                    value={editData.name}
                    onChange={handleChange}
                    className="text-2xl font-bold border rounded px-2 py-1"
                  />
                ) : (
                  <h2 className="text-2xl font-bold text-gray-900">{userData.name}</h2>
                )}
                <div className="flex items-center space-x-2">
                  <Heart className="w-5 h-5 text-pink-500" />
                  <span className="text-gray-600">Stress Level: {userData.stressLevel}</span>
                </div>
              </div>
              
              <div>
                {isEditing ? (
                  <div className="space-x-2">
                    <button
                      onClick={handleSave}
                      className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors inline-flex items-center"
                    >
                      <Check className="w-4 h-4 mr-1" />
                      Save
                    </button>
                    <button
                      onClick={handleCancel}
                      className="px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors inline-flex items-center"
                    >
                      <X className="w-4 h-4 mr-1" />
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={handleEdit}
                    className="px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors inline-flex items-center"
                  >
                    <Edit2 className="w-4 h-4 mr-1" />
                    Edit Profile
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin className="w-5 h-5" />
                  {isEditing ? (
                    <input
                      name="location"
                      value={editData.location}
                      onChange={handleChange}
                      className="border rounded px-2 py-1 flex-1"
                    />
                  ) : (
                    <span>{userData.location}</span>
                  )}
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Mail className="w-5 h-5" />
                  {isEditing ? (
                    <input
                      name="email"
                      type="email"
                      value={editData.email}
                      onChange={handleChange}
                      className="border rounded px-2 py-1 flex-1"
                    />
                  ) : (
                    <span>{userData.email}</span>
                  )}
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="w-5 h-5" />
                  <span>Joined {userData.joined}</span>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900">About Me</h3>
                {isEditing ? (
                  <textarea
                    name="bio"
                    value={editData.bio}
                    onChange={handleChange}
                    rows="4"
                    className="w-full p-2 border rounded-md"
                  />
                ) : (
                  <p className="text-gray-600">{userData.bio}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 text-blue-600 mb-2">
                  <Activity className="w-5 h-5" />
                  <span className="font-semibold">Current Streak</span>
                </div>
                <p className="text-2xl font-bold text-blue-700">{userData.streakDays} days</p>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 text-purple-600 mb-2">
                  <Clock className="w-5 h-5" />
                  <span className="font-semibold">Total Meditation</span>
                </div>
                <p className="text-2xl font-bold text-purple-700">{userData.meditationMinutes} min</p>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 text-green- 600 mb-2">
                  <Award className="w-5 h-5" />
                  <span className="font-semibold">Weekly Goal</span>
                </div>
                <p className="text-2xl font-bold text-green-700">{userData.weeklyGoal}</p>
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-semibold text-gray-900 mb-4">Preferred Activities</h3>
              <div className="flex flex-wrap gap-2">
                {userData.preferredActivities.map((activity, index) => (
                  <span 
                    key={index}
                    className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm"
                  >
                    {activity}
                  </span>
                ))}
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-semibold text-gray-900 mb-4">Recent Wellness Activities</h3>
              <div className="space-y-4">
                {[
                  { activity: 'Completed 15-minute meditation session', time: '2 hours ago' },
                  { activity: 'Logged stress level - Feeling calmer', time: '1 day ago' },
                  { activity: 'Completed breathing exercise', time: '2 days ago' }
                ].map((item, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-2 h-2 mt-2 rounded-full bg-blue-500" />
                    <div>
                      <p className="text-gray-600">{item.activity}</p>
                      <p className="text-sm text-gray-400">{item.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Settings Section */}
            <div className="border-t pt-6">
              <h3 className="font-semibold text-gray-900 mb-4">Settings</h3>

              {/* Account Management */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <User  className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">Account Management</h2>
                </div>
                <div className="flex items-center mb-4">
                  <img
                    src={profileImage}
                    alt="Profile"
                    className="w-16 h-16 rounded-full mr-4"
                  />
                  <div>
                    <button onClick={handleImageUpload} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                      Upload Photo
                    </button>
                  </div>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Email</span>
                  <span className="text-gray-600">user@example.com</span>
                </div>
              </div>

              {/* Notifications */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Bell className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">Notifications</h2>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Push Notifications</span>
                  <input type="checkbox" checked={notifications} onChange={() => setNotifications(!notifications)} />
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Mood Logging Reminders</span>
                  <input type="checkbox" checked={moodReminders} onChange={() => setMoodReminders(!moodReminders)} />
                </div>
              </div>

              {/* Privacy */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Lock className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">Privacy</h2>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Data Sharing</span>
                  <input type="checkbox" checked={dataSharing} onChange={() => setDataSharing(!dataSharing)} />
                </div>
                <div className="flex items-center justify-between py-2">
                  <button className="text-sm text-blue-500 hover:underline mt-2">
                    View Privacy Policy
                  </button>
                </div>
              </div>

              {/* Device Integration */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Smartphone className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">Device Integration</h2>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Connected Devices</span>
                  <button className="flex items-center text-blue-500 hover:underline">
                    Manage
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </button>
                </div>
              </div>

              {/* Display */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Moon className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">Display</h2>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Dark Mode</span>
                  <input type="checkbox" checked={darkMode} onChange={() => setDarkMode(!darkMode)} />
                </div>
              </div>

              {/* App Preferences */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Globe className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">App Preferences</h2>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Language</span>
                  <select className="border rounded p-1">
                    <option>English</option>
                    <option>Spanish</option>
                    <option>French</option>
                  </select>
                </div>
              </div>

              {/* Data Management */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Download className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">Data Management</h2>
                </div>
                <button className="text-blue-500 hover:underline">
                  Download My Data
                </button>
              </div>

              {/* Security */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Shield className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">Security</h2>
                </div>
                <button className="text-blue-500 hover:underline">
                  Change Password
                </button>
              </div>

              {/* About */}
              <div className="mb-6 p-4 bg-white rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <Info className="w-5 h-5 mr-2 text-blue-500" />
                  <h2 className="text-lg font-semibold">About</h2>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm">Version</span>
                  <span className="text-gray-600">1.0.0</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;