
import {
  Trophy
} from 'lucide-react';
const Challenges = () => {
    const challenges = [
      {
        id: 1,
        title: "7-Day Meditation Challenge",
        participants: 345,
        daysLeft: 3,
        description: "Practice mindfulness for 10 minutes daily",
        progress: 70
      },
      {
        id: 2,
        title: "Stress-Free Workplace Week",
        participants: 567,
        daysLeft: 5,
        description: "Implement stress management techniques at work",
        progress: 45
      }
    ];
  
    return (
      <div className="grid gap-4 md:grid-cols-2">
        {challenges.map(challenge => (
          <div key={challenge.id} className="bg-white rounded-lg shadow-md p-4">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              <h3 className="font-semibold text-lg">{challenge.title}</h3>
            </div>
            <p className="text-sm text-gray-600 mb-3">{challenge.description}</p>
            <div className="flex justify-between text-sm text-gray-500 mb-2">
              <span>{challenge.participants} participants</span>
              <span>{challenge.daysLeft} days left</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
              <div 
                className="bg-yellow-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${challenge.progress}%` }}
              />
            </div>
            <button className="w-full py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition-colors">
              Join Challenge
            </button>
          </div>
        ))}
      </div>
    );
  };

  export default Challenges;