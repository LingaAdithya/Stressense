
import { 
  Users, 
  Clock,

  Calendar, 
  UserCircle
} from 'lucide-react';

const Events = () => {
    const events = [
      {
        id: 1,
        title: "Virtual Meditation Session",
        date: "2024-11-15",
        time: "10:00 AM",
        host: "Dr. Emily Chen",
        attendees: 45,
        type: "Virtual"
      },
      {
        id: 2,
        title: "Stress Management Workshop",
        date: "2024-11-20",
        time: "2:00 PM",
        host: "John Smith",
        attendees: 78,
        type: "In-Person"
      }
    ];
  
    return (
      <div className="space-y-4">
        {events.map(event => (
          <div key={event.id} className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-5 w-5 text-purple-600" />
              <h3 className="font-semibold text-lg">{event.title}</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="text-sm text-gray-600 space-y-1">
                <p className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" /> {event.date}
                </p>
                <p className="flex items-center gap-2">
                  <Clock className="h-4 w-4" /> {event.time}
                </p>
                <p className="flex items-center gap-2">
                  <UserCircle className="h-4 w-4" /> {event.host}
                </p>
                <p className="flex items-center gap-2">
                  <Users className="h-4 w-4" /> {event.attendees} attending
                </p>
              </div>
              <div className="flex flex-col justify-end">
                <span className="text-sm px-3 py-1 bg-purple-100 text-purple-800 rounded-full self-start mb-2">
                  {event.type}
                </span>
                <button className="w-full py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
                  Register
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  export default Events;