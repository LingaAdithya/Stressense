import { useState } from 'react';
import { 
  MessageCircle, 
  Heart, 
  Lock,
  UserCircle,
  Send
} from 'lucide-react';
const AnonymousPosting = () => {
    const [posts] = useState([
      {
        id: 1,
        content: "Sometimes I feel overwhelmed with work, but I'm afraid to tell my manager...",
        timestamp: "10 minutes ago",
        reactions: 12,
        comments: 5
      },
      {
        id: 2,
        content: "Does anyone else struggle with anxiety during team meetings? Looking for coping strategies.",
        timestamp: "1 hour ago",
        reactions: 24,
        comments: 8
      }
    ]);
  
    return (
      <div className="space-y-6">
        {/* New Post Input */}
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center gap-2 mb-4">
            <Lock className="h-5 w-5 text-gray-500" />
            <h3 className="font-semibold">Share Anonymously</h3>
          </div>
          <textarea 
            className="w-full p-3 border rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Share your thoughts anonymously..."
            rows={4}
          />
          <div className="flex justify-between items-center mt-4">
            <p className="text-sm text-gray-500">Your identity will remain hidden</p>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center gap-2">
              <Send className="h-4 w-4" />
              Post Anonymously
            </button>
          </div>
        </div>
  
        {/* Anonymous Posts */}
        <div className="space-y-4">
          {posts.map(post => (
            <div key={post.id} className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center gap-2 mb-2">
                <UserCircle className="h-6 w-6 text-gray-400" />
                <span className="text-gray-500">Anonymous</span>
                <span className="text-xs text-gray-400">• {post.timestamp}</span>
              </div>
              <p className="text-gray-700 mb-4">{post.content}</p>
              <div className="flex gap-4 text-sm text-gray-500">
                <button className="flex items-center gap-1 hover:text-blue-600 transition-colors">
                  <Heart className="h-4 w-4" />
                  {post.reactions}
                </button>
                <button className="flex items-center gap-1 hover:text-blue-600 transition-colors">
                  <MessageCircle className="h-4 w-4" />
                  {post.comments}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };
  
  export default AnonymousPosting;