import { Users } from 'lucide-react';
const SupportGroups = () => {
  const groups = [
    {
      id: 1,
      name: "Workplace Stress Management",
      members: 234,
      description: "A safe space to discuss and share workplace stress coping strategies.",
      category: "Professional"
    },
    {
      id: 2,
      name: "Mindfulness Practice",
      members: 156,
      description: "Daily mindfulness exercises and meditation support group.",
      category: "Wellness"
    },
    {
      id: 3,
      name: "Student Support Circle",
      members: 189,
      description: "Supporting students dealing with academic pressure and stress.",
      category: "Education"
    }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {groups.map(group => (
        <div key={group.id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-4">
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-1">
              <Users className="h-5 w-5 text-blue-600" />
              <h3 className="font-semibold text-lg">{group.name}</h3>
            </div>
            <span className="text-sm text-gray-500">{group.members} members</span>
          </div>
          <p className="text-sm text-gray-600 mb-4">{group.description}</p>
          <div className="flex justify-between items-center">
            <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
              {group.category}
            </span>
            <button className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
              Join Group
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SupportGroups;