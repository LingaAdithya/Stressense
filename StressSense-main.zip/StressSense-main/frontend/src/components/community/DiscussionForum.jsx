
import { 
  Users, 
  MessageCircle
} from 'lucide-react';


const DiscussionForums = () => {
    const discussions = [
      {
        id: 1,
        title: "Managing Work-Life Balance",
        author: "Sarah J.",
        replies: 23,
        views: 156,
        lastActive: "2h ago",
        tags: ["Work", "Balance"]
      },
      {
        id: 2,
        title: "Effective Breathing Techniques",
        author: "Mike R.",
        replies: 45,
        views: 289,
        lastActive: "1h ago",
        tags: ["Wellness", "Meditation"]
      }
    ];
  
    return (
      <div className="space-y-4">
        {discussions.map(discussion => (
          <div key={discussion.id} className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="font-semibold text-lg mb-1">{discussion.title}</h3>
                <div className="flex flex-wrap gap-2 mb-2">
                  {discussion.tags.map(tag => (
                    <span key={tag} className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
                <p className="text-sm text-gray-500">Started by {discussion.author}</p>
              </div>
              <div className="flex gap-4 text-sm text-gray-500">
                <div className="flex items-center gap-1">
                  <MessageCircle className="h-4 w-4" />
                  {discussion.replies}
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {discussion.views}
                </div>
                <div>{discussion.lastActive}</div>
              </div>
            </div>
          </div>
        ))}
        <button className="w-full py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
          Start New Discussion
        </button>
      </div>
    );
  };

  export default DiscussionForums