import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Settings,
  LogOut,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import PropTypes from 'prop-types';

const UserMenu = ({ username = "Guest", onLogout = () => {} }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle animation timing
  useEffect(() => {
    if (isOpen) {
      setIsAnimating(true);
    } else {
      const timer = setTimeout(() => setIsAnimating(false), 200); // Match with CSS transition duration
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleLogout = async () => {
    setIsOpen(false);
    if (onLogout) {
      await onLogout();
    }
    navigate('/login'); // Redirect to login page after logout
  };

  const handleNavigation = (path) => {
    setIsOpen(false);
    navigate(path);
  };


  return (
    <div className="relative" ref={dropdownRef}>
      {/* User Button */}
      <button
        onClick={handleToggle}
        className="flex items-center space-x-2 text-gray-700 hover:bg-gray-100 p-2 rounded-md transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
          <User className="w-5 h-5 text-primary-600" />
        </div>
        <span className="font-medium hidden sm:inline">{username}</span>
        <div className="transition-transform duration-200 ease-in-out">
          {isOpen ? (
            <ChevronUp className={`w-4 h-4 transform ${isOpen ? 'rotate-0' : 'rotate-180'}`} />
          ) : (
            <ChevronDown className={`w-4 h-4 transform ${isOpen ? 'rotate-180' : 'rotate-0'}`} />
          )}
        </div>
      </button>

      
        {isAnimating && (
          <div
            className={`absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 
               transition-all duration-200 ease-in-out
               ${isOpen
                 ? 'opacity-100 transform translate-y-0'
                 : 'opacity-0 transform -translate-y-2'}`}
            role="menu"
            aria-orientation="vertical"
            aria-labelledby="user-menu-button"
          >
            <div className="py-1">
          {/* Profile Option */}
          <button onClick={() => handleNavigation('/profile')} // Updated path
          className="w-full text-left group flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-150"
          role="menuitem">
            <User  className="w-4 h-4 mr-3 text-gray-500 group-hover:text-primary-600 transition-colors duration-150" />
            <span className="group-hover:text-primary-600 transition-colors duration-150">Profile</span>
            </button>

          {/* Settings Option */}
            <button onClick={() => handleNavigation('/profile')}
              className="w-full text-left group flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-150"
              role="menuitem"
            >
              <Settings className="w-4 h-4 mr- text-gray-500 group-hover:text-primary-600 transition-colors duration-150" />
              <span className="group-hover:text-primary-600 transition-colors duration-150"> Settings</span>
            </button>

            {/* Divider */}
            <div className="h-px bg-gray-200 my-1" role="none" />

            {/* Logout Option */}
            <button
              onClick={handleLogout}
              className="w-full text-left group flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors duration-150"
              role="menuitem"
            >

              <LogOut className="w-4 h-4 mr-3 text-red-500 group-hover:text-red-600 transition-colors duration-150" />
              <span className="group-hover:text-red-700 transition-colors duration-150">Logout</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

UserMenu.propTypes = {
  username: PropTypes.string.isRequired,
  onLogout: PropTypes.func,
};

UserMenu.defaultProps = {
  onLogout: () => {},
};

export default UserMenu;