// RecommendationPanel/MindfulnessExercises.jsx
import { Brain } from 'lucide-react';
import PropTypes from 'prop-types';

const MindfulnessExercises = ({ exercises = [] }) => {
  const defaultExercises = [
    { id: 1, title: 'Breathing Exercise', duration: '5 mins', type: 'Breathing' },
    { id: 2, title: 'Body Scan', duration: '10 mins', type: 'Meditation' },
    { id: 3, title: 'Guided Visualization', duration: '15 mins', type: 'Visualization' },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-4 flex-">
      <div className="flex items-center gap-2 mb-4 text-black">
        <Brain size={24} />
        <h3 className="text-lg font-semibold text-black">Mindfulness Exercises</h3>
      </div>
      <div className="space-y-3">
        {(exercises.length ? exercises : defaultExercises).map((exercise) => (
          <div key={exercise.id} className="p-3 bg-gray-50 rounded-md">
            <h4 className="font-medium text-black">{exercise.title}</h4>
            <div className="text-sm text-gray-500">
              Duration: {exercise.duration} • Type: {exercise.type}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
MindfulnessExercises.propTypes = {
  exercises: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      title: PropTypes.string.isRequired,
      duration: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired,
    })
  ),
};

export default MindfulnessExercises;
