import { useState } from 'react';
import PropTypes from 'prop-types';
import { Play, Pause, SkipForward, SkipBack, Music } from 'lucide-react';

const MusicPlayer = ({ playlist = [] }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const defaultPlaylist = [
    { id: 1, title: 'Calm Meditation', artist: 'Nature Sounds', duration: '5:30' },
    { id: 2, title: 'Peaceful Piano', artist: 'Classical Beats', duration: '4:45' },
    { id: 3, title: 'Ocean Waves', artist: 'Ambient Sounds', duration: '6:15' },
  ];
//flex items-center gap-2 mb-4 text-black
  return (
    <div className="bg-white flexrounded-lg shadow-md p-4 flex-">
      <div className="flex items-center gap-2 mb-4 text-black">
        <Music size={24} />
        <h3 className="text-lg font-semibold text-black">Relaxation Music</h3>
      </div>
      <div className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
          <div>
            <h4 className="font-medium text-black">{(playlist[0] || defaultPlaylist[0]).title}</h4>
            <p className="text-sm text-gray-500">{(playlist[0] || defaultPlaylist[0]).artist}</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-200 rounded-full">
              <SkipBack size={20} />
            </button>
            <button 
              className="p-2 hover:bg-gray-200 rounded-full"
              onClick={() => setIsPlaying(!isPlaying)}
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
            </button>
            <button className="p-2 hover:bg-gray-200 rounded-full">
              <SkipForward size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

MusicPlayer.propTypes = {
  playlist: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      title: PropTypes.string.isRequired,
      artist: PropTypes.string.isRequired,
      duration: PropTypes.string.isRequired,
    })
  ),
};
export default MusicPlayer;