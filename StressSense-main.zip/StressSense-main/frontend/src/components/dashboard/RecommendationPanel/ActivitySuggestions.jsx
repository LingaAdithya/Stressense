// RecommendationPanel/ActivitySuggestions.jsx
import PropTypes from 'prop-types';
import { Activity } from 'lucide-react';

const ActivitySuggestions = ({ suggestions = [] }) => {
  const defaultSuggestions = [
    { id: 1, title: 'Morning Walk', duration: '20 mins', intensity: 'Low' },
    { id: 2, title: 'Desk Stretches', duration: '5 mins', intensity: 'Low' },
    { id: 3, title: 'Evening Yoga', duration: '30 mins', intensity: 'Medium' },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center gap-2 mb-4 text-black">
        <Activity size={24} />
        <h3 className="text-lg font-semibold text-black">Recommended Activities</h3>
      </div>
      <div className="space-y-3">
        {(suggestions.length ? suggestions : defaultSuggestions).map((activity) => (
          <div key={activity.id} className="p-3 bg-gray-50 rounded-md">
            <h4 className="font-medium text-black">{activity.title}</h4>
            <div className="text-sm text-gray-500">
              Duration: {activity.duration} • Intensity: {activity.intensity}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
ActivitySuggestions.propTypes = {
  suggestions: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      title: PropTypes.string.isRequired,
      duration: PropTypes.string.isRequired,
      intensity: PropTypes.string.isRequired,
    })
  ),
};
export default ActivitySuggestions;