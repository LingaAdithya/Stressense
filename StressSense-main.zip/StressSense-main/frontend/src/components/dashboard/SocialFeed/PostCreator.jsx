// SocialFeed/PostCreator.jsx
import { useState } from 'react';
import { Image, Smile, Send } from 'lucide-react';
import PropTypes from 'prop-types';

const PostCreator = ({ onPost }) => {
  const [content, setContent] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (content.trim()) {
      onPost?.(content);
      setContent('');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-4 text-black">
      <form onSubmit={handleSubmit}>
        <textarea
          className="w-full p-3 border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Share your thoughts..."
          rows="3"
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
        <div className="flex items-center justify-between mt-3">
          <div className="flex gap-2">
            <button type="button" className="p-2 hover:bg-gray-100 rounded-full">
              <Image size={20} />
            </button>
            <button type="button" className="p-2 hover:bg-gray-100 rounded-full">
              <Smile size={20} />
            </button>
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 flex items-center gap-2"
            disabled={!content.trim()}
          >
            <Send size={16} />
            Post
          </button>
        </div>
      </form>
    </div>
  );
};

PostCreator.propTypes = {
  onPost: PropTypes.func.isRequired,
};

export default PostCreator;