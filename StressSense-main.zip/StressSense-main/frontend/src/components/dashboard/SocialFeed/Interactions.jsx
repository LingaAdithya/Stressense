// SocialFeed/Interactions.jsx
import PropTypes from 'prop-types';
const Interactions = ({ post }) => {
  const defaultInteractions = {
    likes: ['Jane Doe', 'John Smith'],
    comments: [
      { id: 1, user: 'Jane Doe', content: 'Great progress!', timestamp: '1 hour ago' },
      { id: 2, user: 'John Smith', content: 'Keep it up! 👍', timestamp: '30 mins ago' },
    ],
  };

  const interactions = post?.interactions || defaultInteractions;

  return (
    <div className="bg-white rounded-lg shadow-md p-4 text-black">
      <div className="mb-4 text-black">
        <h4 className="font-medium mb-2">Likes ({interactions.likes.length})</h4>
        <div className="text-sm text-gray-500 space-y-1">
          {interactions.likes.join(', ')} liked this post
        </div>
      </div>
      <div>
        <h4 className="font-medium mb-2 text-black">Comments ({interactions.comments.length})</h4>
        <div className="space-y-3">
          {interactions.comments.map((comment) => (
            <div key={comment.id} className="p-3 bg-gray-50 rounded-md">
              <div className="flex justify-between">
                <span className="font-medium">{comment.user}</span>
                <span className="text-sm text-gray-500">{comment.timestamp}</span>
              </div>
              <p className="mt-1 text-sm">{comment.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

Interactions.propTypes = {
  post: PropTypes.shape({
    interactions: PropTypes.shape({
      likes: PropTypes.arrayOf(PropTypes.string),
      comments: PropTypes.arrayOf(
        PropTypes.shape({
          id: PropTypes.number,
          user: PropTypes.string,
          content: PropTypes.string,
          timestamp: PropTypes.string,
        })
      ),
    }),
  }),
};

export default Interactions;