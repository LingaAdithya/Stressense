
// SocialFeed/FeedPost.jsx
import { Heart, MessageCircle, Share2 } from 'lucide-react';
import PropTypes from 'prop-types';

const FeedPost = ({ post }) => {
  const defaultPost = {
    id: 1,
    user: {
      name: 'Jane Doe',
      avatar: '/api/placeholder/40/40',
    },
    content: 'Just completed a 20-minute meditation session. Feeling much more relaxed now! 🧘‍♀️',
    timestamp: '2 hours ago',
    likes: 12,
    comments: 3,
  };

  const postData = post || defaultPost;

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-4">
      <div className="flex items-center gap-3 mb-4 text-black">
        <img 
          src={postData.user.avatar} 
          alt={postData.user.name} 
          className="w-10 h-10 rounded-full"
        />
        <div>
          <h4 className="font-medium text-black">{postData.user.name}</h4>
          <p className="text-sm text-gray-500">{postData.timestamp}</p>
        </div>
      </div>
      <p className="mb-4 text-gray-600">{postData.content}</p>
      <div className="flex items-center gap-6 text-gray-500">
        <button className="flex items-center gap-1 hover:text-blue-500">
          <Heart size={20} className="text-red-500"/> {postData.likes}
        </button>
        <button className="flex items-center gap-1 hover:text-blue-500">
          <MessageCircle size={20} className="text-yellow-500"/> {postData.comments}
        </button>
        <button className="flex items-center gap-1 hover:text-blue-500">
          <Share2 size={20} className="text-green-500"/>
        </button>
      </div>
    </div>
  );
};
FeedPost.propTypes = {
  post: PropTypes.shape({
    id: PropTypes.number,
    user: PropTypes.shape({
      name: PropTypes.string,
      avatar: PropTypes.string,
    }),
    content: PropTypes.string,
    timestamp: PropTypes.string,
    likes: PropTypes.number,
    comments: PropTypes.number,
  }),
};

export default FeedPost;