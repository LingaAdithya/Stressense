
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import PropTypes from 'prop-types';

const StressGraph = ({ data }) => {
  const defaultData = [
    { time: '9:00', stressLevel: 3 },
    { time: '10:00', stressLevel: 4 },
    { time: '11:00', stressLevel: 6 },
    { time: '12:00', stressLevel: 5 },
    { time: '13:00', stressLevel: 7 },
    { time: '14:00', stressLevel: 4 },
  ];

  return (
    <div className="w-full h-64 bg-white rounded-lg shadow-md p-4">
      <h3 className="text-lg font-semibold mb-4 text-black">Stress Levels Over Time</h3>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data || defaultData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" />
          <YAxis domain={[0, 10]} />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="stressLevel" stroke="#8884d8" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
StressGraph.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      time: PropTypes.string.isRequired,
      stressLevel: PropTypes.number.isRequired,
    })
  ),
};

export default StressGraph;


// // src/components/dashboard/StressMetrics/StressGraph.jsx
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
// import PropTypes from 'prop-types';

// const StressGraph = ({ data }) => {
//   return (
//     <div className="card">
//       <h3 className="text-lg font-semibold text-gray-900 mb-4">Stress Levels Over Time</h3>
//       <div className="h-64">
//         <ResponsiveContainer width="100%" height="100%">
//           <LineChart data={data || []}>
//             <CartesianGrid strokeDasharray="3 3" />
//             <XAxis dataKey="time" />
//             <YAxis />
//             <Tooltip />
//             <Line 
//               type="monotone" 
//               dataKey="stressLevel" 
//               stroke="#0ea5e9" 
//               strokeWidth={2}
//             />
//           </LineChart>
//         </ResponsiveContainer>
//       </div>
//     </div>
//   );
// };
// StressGraph.propTypes = {
//   data: PropTypes.arrayOf(
//     PropTypes.shape({
//       time: PropTypes.string.isRequired,
//       stressLevel: PropTypes.number.isRequired,
//     })
//   ).isRequired,
// };

// export default StressGraph;