
import { Heart } from 'lucide-react';
import PropTypes from 'prop-types';

const HeartRateDisplay = ({ heartRate = 75 }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-lg font-semibold text-black">Heart Rate</h3>
        <Heart className="text-red-500" size={24} />
      </div>
      <div className="text-3xl font-bold text-center text-black">
        {heartRate} <span className="text-sm text-gray-500">BPM</span>
      </div>
      <div className="mt-2 text-sm text-gray-500 text-center">
        Normal Range: 60-100 BPM
      </div>
    </div>
  );
};
HeartRateDisplay.propTypes = {
  heartRate: PropTypes.number,
};

export default HeartRateDisplay;

