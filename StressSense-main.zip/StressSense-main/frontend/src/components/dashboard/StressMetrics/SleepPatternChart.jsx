
// StressMetrics/SleepPatternChart.jsx
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import PropTypes from 'prop-types';

const SleepPatternChart = ({ data }) => {
  const defaultData = [
    { day: 'Mon', hours: 7.5, quality: 8 },
    { day: 'Tue', hours: 6.8, quality: 7 },
    { day: 'Wed', hours: 7.2, quality: 8 },
    { day: 'Thu', hours: 6.5, quality: 6 },
    { day: 'Fri', hours: 8.0, quality: 9 },
    { day: 'Sat', hours: 7.8, quality: 8 },
    { day: 'Sun', hours: 7.0, quality: 7 },
  ];

  return (
    <div className="w-full h-64 bg-white rounded-lg shadow-md p-4">
      <h3 className="text-lg font-semibold mb-4 text-black">Sleep Pattern</h3>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data || defaultData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="day" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="hours" fill="#8884d8" name="Hours Slept" />
          <Bar dataKey="quality" fill="#82ca9d" name="Sleep Quality" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
SleepPatternChart.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      day: PropTypes.string.isRequired,
      hours: PropTypes.number.isRequired,
      quality: PropTypes.number.isRequired,
    })
  ),
};

export default SleepPatternChart;