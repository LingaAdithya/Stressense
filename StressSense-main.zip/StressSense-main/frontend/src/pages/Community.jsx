import { useState } from 'react';
import { Users, MessageCircle, Trophy, Calendar, Lock} from 'lucide-react';
import SupportGroups from '../components/community/SupportGroups';
import DiscussionForums from '../components/community/DiscussionForum';
import Challenges from '../components/community/Challenges';
import Events from '../components/community/Events';
import AnonymousPosting from '../components/community/AnonymousPosting';


const CommunityPage = () => {
    const [activeTab, setActiveTab] = useState('support-groups');
  
    const tabs = [
      { id: 'support-groups', label: 'Support Groups', icon: Users },
      { id: 'discussions', label: 'Discussions', icon: MessageCircle },
      { id: 'challenges', label: 'Challenges', icon: Trophy },
      { id: 'events', label: 'Events', icon: Calendar },
      { id: 'anonymous', label: 'Anonymous Posts', icon: Lock }
    ];
  
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-gray-800">StressSense Community</h1>
        
        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-6">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <tab.icon className="h-5 w-5" />
              {tab.label}
            </button>
          ))}
        </div>
  
        {/* Tab Content */}
        <div className="bg-gray-50 rounded-lg p-6">
          {activeTab === 'support-groups' && <SupportGroups />}
          {activeTab === 'discussions' && <DiscussionForums />}
          {activeTab === 'challenges' && <Challenges />}
          {activeTab === 'events' && <Events />}
          {activeTab === 'anonymous' && <AnonymousPosting />}
        </div>
      </div>
    );
  };
  
  export default CommunityPage;