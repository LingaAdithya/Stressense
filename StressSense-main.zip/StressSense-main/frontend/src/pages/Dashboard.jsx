// Dashboard.jsx
//RecommendationPanel
import { useState } from 'react';
import ActivitySuggestions from '../components/dashboard/RecommendationPanel/ActivitySuggestions';
import MindfulnessExercises from '../components/dashboard/RecommendationPanel/MindfulnessExercises';
import MusicPlayer from '../components/dashboard/RecommendationPanel/MusicPlayer';
//ActivitySuggestions
import FeedPost from '../components/dashboard/SocialFeed/FeedPost';
import Interactions from '../components/dashboard/SocialFeed/Interactions';
import PostCreator from '../components/dashboard/SocialFeed/PostCreator';
//StressMetrics
import HeartRateDisplay from '../components/dashboard/StressMetrics/HeartRateDisplay';
import SleepPatternChart from '../components/dashboard/StressMetrics/SleepPatternChart';
import StressGraph from '../components/dashboard/StressMetrics/StressGraph';
 import { History } from 'lucide-react';
const Dashboard = () => {
  // State for managing posts in the social feed
  const [posts, setPosts] = useState([
    {
      id: 1,
      user: {
        name: 'Jane Doe',
        avatar: '/api/placeholder/40/40',
      },
      content: 'Just completed a 20-minute meditation session. Feeling much more relaxed now! 🧘‍♀️',
      timestamp: '2 hours ago',
      likes: 12,
      comments: 3,
    },
    // Add more sample posts as needed
  ]);

  // Handler for creating new posts
  const handleNewPost = (content) => {
    const newPost = {
      id: posts.length + 1,
      user: {
        name: 'Current User',
        avatar: '/api/placeholder/40/40',
      },
      content,
      timestamp: 'Just now',
      likes: 0,
      comments: 0,
    };
    setPosts([newPost, ...posts]);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Wellness Dashboard</h1>
          <p className="text-gray-500">Monitor your stress levels and well-being</p>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Metrics */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stress Metrics Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <StressGraph />
              </div>
              <HeartRateDisplay />
              <div className="h-full">
                <SleepPatternChart />
              </div>
            </div>

            {/* Social Feed Section */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 text-black">Community Feed</h2>
              <PostCreator onPost={handleNewPost} />
              <div className="space-y-4">
                {posts.map((post) => (
                  <FeedPost key={post.id} post={post} />
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Recommendations */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 text-black">Recommendations</h2>
              <div className="space-y-6">
                <ActivitySuggestions />
                <MusicPlayer />
                <MindfulnessExercises />
              </div>
            </div>
            
            {/* Recent Interactions */}
            <div className="bg-white rounded-lg shadow-md p-6 ">
            <div className="flex items-center gap-2 mb-4 text-black">
        <History size={24} />
        <h3 className="text-lg font-semibold text-black">Mindfulness Exercises</h3>
      </div>
              <h2 className="text-xl font-semibold mb-4 text-black">Recent Activity</h2>
              <Interactions />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;