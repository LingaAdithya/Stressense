import 'tailwindcss/tailwind.css';

const About = () => {
    return (
        <div className="container mx-auto p-6">
            <div className="bg-white shadow-md rounded-lg p-6">
                <h2 className="text-2xl font-bold mb-4 text-center">About StressSense</h2>
                <p className="text-gray-700 mb-4">
                    StressSense is your personal companion for managing stress and enhancing mental well-being.
                    Our application leverages cutting-edge technology to monitor your physiological data,
                    detect stress levels, and provide personalized recommendations for stress relief.
                </p>
                <p className="text-gray-700 mb-4">
                    We believe that mental health is just as important as physical health. With StressSense,
                    you can track your stress triggers, engage in mindfulness practices, and connect with a supportive community.
                    Our goal is to empower you to take control of your mental well-being.
                </p>
                <h3 className="text-xl font-semibold mb-2">Features:</h3>
                <ul className="list-disc list-inside text-gray-700">
                    <li className="mb-2">Automated stress detection using physiological data.</li>
                    <li className="mb-2">Personalized recommendations for stress management.</li>
                    <li className="mb-2">Community support through social sharing.</li>
                    <li className="mb-2">Crisis alerts for timely assistance.</li>
                </ul>
            </div>
        </div>
    );
};

export default About;