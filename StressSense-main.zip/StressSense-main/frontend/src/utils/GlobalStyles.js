import { createGlobalStyle } from 'styled-components';

const GlobalStyles = createGlobalStyle`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f2f5;
  },
  h1  {
    font-size: 24px;
    font-weight: bold;
    color: #333;
  },
  h2 {
    font-size: 20px;
    font-weight: bold;
    color: #333;
  },
  h3 {
    font-size: 18px;
    font-weight: bold;
    color: #333;
  },
  h4 {
    font-size: 16px;
    font-weight: bold;
    color: #333;
  },
  h5 {
    font-size: 14px;
    font-weight: bold;
    color: #333;
  },
`;

export default GlobalStyles;
