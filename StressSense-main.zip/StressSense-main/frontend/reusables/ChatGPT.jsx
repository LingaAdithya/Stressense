import { useState, useCallback, useRef } from 'react';
import "@chatscope/chat-ui-kit-styles/dist/default/styles.min.css";
import {
  MainContainer,
  ChatContainer,
  MessageList,
  Message,
  MessageInput,
  TypingIndicator,
  ConversationHeader
} from '@chatscope/chat-ui-kit-react';

// API Configuration
const API_KEY = "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";

// Rate limiting configuration
const RATE_LIMIT_CONFIG = {
  maxRetries: 3,
  initialDelay: 1000, // 1 second
  maxDelay: 10000,    // 10 seconds
  backoffFactor: 2,   // Double the delay each retry
  requestTimeout: 30000 // 30 seconds
};

const INITIAL_MESSAGE = {
  message: "Hello, I'm Chatbot! Ask me anything!",
  sentTime: new Date().toISOString(),
  sender: "ChatGPT",
  direction: "incoming"
};

const systemMessage = {
  role: "system",
  content: "Explain things like you're talking to a software professional with 2 years of experience."
};

const ChatGPT = () => {
  const [messages, setMessages] = useState([INITIAL_MESSAGE]);
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState(null);
  const requestQueue = useRef([]);
  const isProcessing = useRef(false);

  // Helper function to delay execution
  const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // Calculate backoff delay
  const getBackoffDelay = (retryCount) => {
    const backoffDelay = RATE_LIMIT_CONFIG.initialDelay * 
      Math.pow(RATE_LIMIT_CONFIG.backoffFactor, retryCount);
    return Math.min(backoffDelay, RATE_LIMIT_CONFIG.maxDelay);
  };

  const addMessage = useCallback((message, sender, direction = 'incoming') => {
    const newMessage = {
      message,
      sender,
      direction,
      sentTime: new Date().toISOString()
    };
    setMessages(prev => [...prev, newMessage]);
  }, []);

  // Process the message queue
  const processQueue = useCallback(async () => {
    if (isProcessing.current || requestQueue.current.length === 0) return;

    isProcessing.current = true;
    
    try {
      while (requestQueue.current.length > 0) {
        const nextRequest = requestQueue.current[0];
        await processMessageToChatGPT(nextRequest.messages, nextRequest.retryCount);
        requestQueue.current.shift(); // Remove processed request
        
        if (requestQueue.current.length > 0) {
          // Add delay between requests to avoid rate limiting
          await delay(1000);
        }
      }
    } catch (error) {
      console.error("Queue processing error:", error);
      setError("An error occurred while processing messages. Please try again.");
    } finally {
      isProcessing.current = false;
    }
  }, []);

  const processMessageToChatGPT = useCallback(async (chatMessages, retryCount = 0) => {
    const apiMessages = chatMessages.map(messageObject => ({
      role: messageObject.sender === "ChatGPT" ? "assistant" : "user",
      content: messageObject.message
    }));

    const apiRequestBody = {
      model: "gpt-3.5-turbo",
      messages: [systemMessage, ...apiMessages],
      temperature: 0.7,
      max_tokens: 2000
    };

    try {
      setError(null);
      setIsTyping(true); // Start typing indicator
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), RATE_LIMIT_CONFIG.requestTimeout);

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(apiRequestBody),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (response.status === 429) {
        if (retryCount < RATE_LIMIT_CONFIG.maxRetries) {
          const backoffDelay = getBackoffDelay(retryCount);
          console.warn(`Rate limit exceeded. Retrying in ${backoffDelay}ms... (Attempt ${retryCount + 1}/${RATE_LIMIT_CONFIG.maxRetries})`);
          await delay(backoffDelay);
          
          // Add back to queue with increased retry count
          requestQueue.current.push({
            messages: chatMessages,
            retryCount: retryCount + 1
          });
          
          // Call processQueue to handle the new request
          processQueue();
          return;
        }
        throw new Error("Rate limit exceeded. Please try again later.");
      }

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.choices?.[0]?.message?.content) {
        throw new Error("Invalid response format from API");
      }

      addMessage(data.choices[0].message.content, "ChatGPT");

    } catch (error) {
      if (error.name === 'AbortError') {
        throw new Error("Request timed out. Please try again.");
      }
      throw error;
    } finally {
      setIsTyping(false); // Stop typing indicator
    }
  }, [addMessage, processQueue]);

  const handleSend = useCallback(async (message) => {
    if (!message.trim()) return;

    try {
      addMessage(message, "user", "outgoing");
      
      const newMessages = [...messages, {
        message,
        sender: "user",
        direction: "outgoing",
        sentTime: new Date().toISOString()
      }];

      // Add request to queue
      requestQueue.current.push({
        messages: newMessages,
        retryCount: 0
      });

      // Start processing queue if not already processing
      if (!isProcessing.current) {
        processQueue();
      }

    } catch (error) {
      console.error("Error in handleSend:", error);
      setError(error.message || "Failed to send message. Please try again.");
    }
  }, [messages, addMessage, processQueue]);

  return (
    <div className="relative h-[800px] w-[700px] mx-auto shadow-lg rounded-lg overflow-hidden">
      <MainContainer>
        <ChatContainer>
          <ConversationHeader>
            <ConversationHeader.Content userName="ChatGPT Assistant" />
          </ConversationHeader>
          
          <MessageList 
            scrollBehavior="smooth" 
            typingIndicator={isTyping ? <TypingIndicator content="ChatGPT is typing..." /> : null}
          >
            {messages.map((message, i) => (
              <Message 
                key={`${message.sender}-${message.sentTime}-${i}`}
                model={message}
                className={error && i === messages.length - 1 ? "text-red-500" : ""}
              />
            ))}
          </MessageList>

          <MessageInput 
            placeholder="Type your message here..." 
            onSend={handleSend} 
            disabled={isTyping}
          />
        </ChatContainer>
      </MainContainer>

      {error && (
        <div className="absolute bottom-20 left-0 right-0 mx-4 p-3 bg-red-100 text-red-700 rounded-md">
          {error}
        </div>
      )}
    </div>
  );
};

export default ChatGPT;