// src/Chatbot.jsx
import { useState, useEffect } from 'react';

const predefinedResponses = {
  hello: "Hi there! How can I assist you today?",
  stress: "It's important to manage stress. Consider deep breathing or talking to someone.",
  relax: "Try some relaxation techniques like meditation or yoga.",
  help: "I'm here to help! What would you like to know?",
  goodbye: "Goodbye! Have a great day!",
  default: "I'm not sure how to help with that. Can you please elaborate?",
};

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  // Effect to add the welcome message when the component mounts
  useEffect(() => {
    setMessages((prev) => [
      ...prev,
      { text: "Welcome to the chatbot! How can I help you today?" }
    ]);
  }, []);

  const handleSend = () => {
    if (input.trim() === '') return;

    // Add user message to chat
    setMessages((prev) => [...prev, { text: input, sender: 'user' }]);

    // Determine bot response based on user input
    const lowerCaseInput = input.toLowerCase();
    let botResponse = predefinedResponses.default;

    // Check for predefined responses
    for (const keyword in predefinedResponses) {
      if (lowerCaseInput.includes(keyword)) {
        botResponse = predefinedResponses[keyword];
        break;
      }
    }

    // Add bot response to chat
    setMessages((prev) => [...prev, { text: botResponse, sender: 'bot' }]);

    // Clear input
    setInput('');
  };

  return (
    <div className="fixed bottom-4 right-4 w-80 border rounded-lg shadow-lg bg-white">
      <div className="p-4 border-b">
        <h2 className="text-lg font-bold">Chatbot</h2>
      </div>
      <div className="h-64 overflow-y-auto p-4">
        {messages.map((msg, index) => (
          <div key={index} className={`mb-2 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block px-3 py-2 rounded-lg ${msg.sender === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-black'}`}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div className="p-4">
        <input
          type="text"
          className="w-full border rounded-lg p-2"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Type your message..."
        />
        <button
          className="mt-2 w-full bg-blue-500 text-white rounded-lg p-2"
          onClick={handleSend}
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default Chatbot;